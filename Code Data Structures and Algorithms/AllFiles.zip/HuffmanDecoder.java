public class HuffmanDecoder {
    static public void main (String args[]) {
        (new HuffmanCoding()).processData(args,false);
    }
}
