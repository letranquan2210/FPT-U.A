public class HuffmanEncoder {
    static public void main (String args[]) {
        (new HuffmanCoding()).processData(args,true);
    }
}

